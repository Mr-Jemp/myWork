<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" scroll="no">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="renderer" content="webkit">
<title>文件管理</title>
<script src="/resource/js/jQuery/jquery-1.11.1.min.js"></script>
<style type="text/css">
<!--
html,body{height:99%;width:99%;}
-->
</style></head>
<body>
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td align="center"><div style="margin-left:5px;margin-top:-93px"><?php echo $_REQUEST['error'];?></div></td>
  </tr>
</table>

</body>
</html>